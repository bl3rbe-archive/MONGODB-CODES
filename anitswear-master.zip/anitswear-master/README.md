# Anit-swear Bot
- [Info]
- [Support Server](https://discord.gg/6gzkUNq)
- Coded By: ! Darkboy🍭#0001


# Self Hosting
- npm i
- edit config.yml
- npm start


# Bot Pics



<img src="https://image.prntscr.com/image/pmqG8RzpS9mw3oDO9lJAFQ.png" alt="Bot Preview">
- Another Images
<img src="https://image.prntscr.com/image/dghGY8XaTCiHRFT_UBwchw.png" alt="Bot Preview">

- Explan Gif
<img src="https://media.giphy.com/media/gsllGfjv3l0io9VGQ5/giphy.gif" alt="Bot Preview">

<h1 align="center">Anit-Raid</h1>

## 📝 Starting Up
- npm i
- npm start

## 💨 Run the projects
- Glitch: [![Remix on Glitch](https://cdn.glitch.com/2703baf2-b643-4da7-ab91-7ee2a2d00b5b%2Fremix-button.svg)](https://glitch.com/edit/#!/import/github/Darkboy-js/anit-raid)
- Repl: [![Run on Repl.it](https://repl.it/badge/github/HELLMAKER0001/Alt-Detector)](https://repl.it/github/Darkboy-js/anit-raid)

## ✨ Contributors
- Contributions are always welcomed :D
- Coded By ! Darkboy🍭#9966

<a href="https://github.com/Darkboy-js/anit-raid">
  <img src="https://cdn.discordapp.com/avatars/697279777974911077/7aef2c8514f059c424c6f41a355ea707.webp?size=256" />
</a>

 - [Support Guild](https://discord.gg/6gzkUNq)
